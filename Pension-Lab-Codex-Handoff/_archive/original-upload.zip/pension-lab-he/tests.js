const assert = require('assert');
const E = require('./engine.js');
function base() {
  return {
    profile:{currentAge:30,currentBalance:100000,monthlySalary:10000,pensionableSalary:10000},
    inflation:{annualRate:0},
    salaryPhases:[{startAge:30,endAge:40,annualGrowth:0,growthType:'nominal'}],
    contribution:{mode:'fixed',fixedAmount:0,fixedGrowsWithSalary:false,employeeRate:0,employerRate:0,severanceRate:0,pensionableSalaryLimit:0},
    returnPhases:[{startAge:30,endAge:40,annualReturn:0,returnType:'nominal'}],
    investment:{blendProtected:false,protectedWeight:.3,protectedRealReturn:.0515},
    careerBreaks:[],fees:{annualBalanceFee:0,depositFee:0},retirement:{retirementAge:40,coefficient:200}
  };
}
// 1: starting balance only, 0 return.
{ const s=base(); const r=E.project(s); assert(Math.abs(r.retirementBalanceNominal-100000)<1e-6); }
// 2: 0 return + fixed contributions.
{ const s=base(); s.contribution.fixedAmount=1000; const r=E.project(s); assert(Math.abs(r.retirementBalanceNominal-(100000+1000*120))<1e-6); }
// 3: 0 inflation means real = nominal.
{ const s=base(); s.returnPhases[0].annualReturn=.05; const r=E.project(s); assert(Math.abs(r.retirementBalanceReal-r.retirementBalanceNominal)<1e-6); }
// 4: career break stops contributions but assets keep compounding.
{ const s=base(); s.returnPhases[0].annualReturn=.05;s.contribution.fixedAmount=1000;s.careerBreaks=[{id:'b',startAge:32,durationMonths:24,contributionDuringBreak:0,salaryResumeMode:'projected'}];const r=E.project(s);const no=base();no.returnPhases[0].annualReturn=.05;no.contribution.fixedAmount=1000;const nr=E.project(no);assert(r.retirementBalanceNominal<nr.retirementBalanceNominal);assert(r.retirementBalanceNominal>100000); }
// 5: salary phase change affects percent contributions.
{ const s=base();s.contribution.mode='percent';s.contribution.employeeRate=.1;s.salaryPhases=[{startAge:30,endAge:35,annualGrowth:0,growthType:'nominal'},{startAge:35,endAge:40,annualGrowth:.1,growthType:'nominal'}];const r=E.project(s);assert(r.totalContributionsNominal>10000*.1*120); }
// 6: coefficient calculation.
{ const fake={retirementBalanceReal:4000000,retirementBalanceNominal:4000000};assert.strictEqual(E.pensionAtCoefficient(fake,200,true),20000); }
// 7: real/nominal conversion round trip.
{ const real=.05,inf=.025;const nom=E.realToNominal(real,inf);assert(Math.abs(E.nominalToReal(nom,inf)-real)<1e-12); }
// 8: blended portfolio is between protected and market when weights are between 0 and 1.
{ const s=base();s.returnPhases[0].annualReturn=.08;s.returnPhases[0].returnType='real';s.inflation.annualRate=.02;s.investment.blendProtected=true;s.investment.protectedWeight=.3;s.investment.protectedRealReturn=.0515;const r=E.project(s);assert(r.retirementBalanceNominal>100000); }
// 9: later retirement adds time and contributions.
{ const s=base();s.contribution.fixedAmount=1000;const r40=E.project(s);s.retirement.retirementAge=45;s.salaryPhases[0].endAge=45;s.returnPhases[0].endAge=45;const r45=E.project(s);assert(r45.retirementBalanceNominal>r40.retirementBalanceNominal); }
// 10: exactly two-year break reduces 24 fixed contributions at 0% return.
{ const s=base();s.contribution.fixedAmount=1000;s.careerBreaks=[{id:'b',startAge:32,durationMonths:24,contributionDuringBreak:0,salaryResumeMode:'projected'}];const r=E.project(s);assert(Math.abs(r.retirementBalanceNominal-(100000+1000*96))<1e-6); }
console.log('All 10 projection-engine tests passed.');
