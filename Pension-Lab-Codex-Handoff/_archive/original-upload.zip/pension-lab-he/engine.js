(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.PensionEngine = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const clamp = (n, min, max) => Math.min(max, Math.max(min, n));
  const annualToMonthly = (r) => Math.pow(1 + r, 1 / 12) - 1;
  const realToNominal = (real, inflation) => (1 + real) * (1 + inflation) - 1;
  const nominalToReal = (nominal, inflation) => (1 + nominal) / (1 + inflation) - 1;

  function findPhase(phases, age) {
    if (!Array.isArray(phases) || !phases.length) return null;
    return phases.find((p) => age >= Number(p.startAge) && age < Number(p.endAge)) ||
      phases.find((p) => age >= Number(p.startAge)) || phases[0];
  }

  function normalizedAnnualRate(rate, type, inflation) {
    const r = Number(rate) || 0;
    return type === 'real' ? realToNominal(r, inflation) : r;
  }

  function inBreak(careerBreaks, age) {
    return (careerBreaks || []).find((b) => age >= Number(b.startAge) && age < Number(b.startAge) + Number(b.durationMonths || 0) / 12) || null;
  }

  function project(input) {
    const s = JSON.parse(JSON.stringify(input));
    const currentAge = Number(s.profile.currentAge);
    const retirementAge = Number(s.retirement.retirementAge);
    if (!(retirementAge > currentAge)) throw new Error('Retirement age must be greater than current age');

    const months = Math.max(1, Math.round((retirementAge - currentAge) * 12));
    const inflationAnnual = Number(s.inflation.annualRate) || 0;
    const monthlyInflation = annualToMonthly(inflationAnnual);
    const baseSalary = Math.max(0, Number(s.profile.monthlySalary) || 0);
    const basePensionable = Math.max(0, Number(s.profile.pensionableSalary ?? baseSalary) || 0);
    const pensionableRatio = baseSalary > 0 ? basePensionable / baseSalary : 1;
    const fixedContributionBase = Math.max(0, Number(s.contribution.fixedAmount) || 0);
    const assetFeeAnnual = clamp(Number(s.fees?.annualBalanceFee) || 0, 0, 0.25);
    const monthlyAssetFee = 1 - Math.pow(1 - assetFeeAnnual, 1 / 12);
    const depositFee = clamp(Number(s.fees?.depositFee) || 0, 0, 0.25);

    let salary = baseSalary;
    let balance = Math.max(0, Number(s.profile.currentBalance) || 0);
    let inflationIndex = 1;
    let totalContributionsNominal = 0;
    let totalContributionsReal = 0;
    let totalFeesNominal = 0;
    let totalFeesReal = 0;
    let totalInvestmentGainNominal = 0;
    let lastBreakId = null;
    let salaryAtBreakStart = null;
    const snapshots = [];

    function snapshot(monthIndex) {
      const age = currentAge + monthIndex / 12;
      snapshots.push({
        month: monthIndex,
        age,
        nominalBalance: balance,
        realBalance: balance / inflationIndex,
        nominalSalary: salary,
        realSalary: salary / inflationIndex,
        totalContributionsNominal,
        totalContributionsReal,
        totalFeesNominal,
        totalFeesReal,
        totalInvestmentGainNominal,
      });
    }

    snapshot(0);

    for (let m = 0; m < months; m++) {
      const age = currentAge + m / 12;
      const activeBreak = inBreak(s.careerBreaks, age);

      if (activeBreak && lastBreakId !== activeBreak.id) {
        salaryAtBreakStart = salary;
        lastBreakId = activeBreak.id;
      }

      // Inflation grows continuously even when not employed.
      inflationIndex *= 1 + monthlyInflation;

      const salaryPhase = findPhase(s.salaryPhases, age);
      const salaryAnnual = normalizedAnnualRate(
        salaryPhase?.annualGrowth || 0,
        salaryPhase?.growthType || 'nominal',
        inflationAnnual
      );
      const salaryMonthlyGrowth = annualToMonthly(salaryAnnual);

      // Contribution for this month is based on salary before end-of-month raise.
      let grossContribution = 0;
      if (activeBreak) {
        grossContribution = Math.max(0, Number(activeBreak.contributionDuringBreak) || 0);
      } else if (s.contribution.mode === 'percent') {
        const pensionableSalary = Math.min(
          salary * pensionableRatio,
          Number(s.contribution.pensionableSalaryLimit) > 0 ? Number(s.contribution.pensionableSalaryLimit) : Infinity
        );
        const rate = (Number(s.contribution.employeeRate) || 0) +
          (Number(s.contribution.employerRate) || 0) +
          (Number(s.contribution.severanceRate) || 0);
        grossContribution = Math.max(0, pensionableSalary * rate);
      } else {
        const grows = !!s.contribution.fixedGrowsWithSalary;
        grossContribution = fixedContributionBase * (grows && baseSalary > 0 ? salary / baseSalary : 1);
      }

      const depositFeeAmount = grossContribution * depositFee;
      const netContribution = grossContribution - depositFeeAmount;
      balance += netContribution;
      totalContributionsNominal += netContribution;
      totalContributionsReal += netContribution / inflationIndex;
      totalFeesNominal += depositFeeAmount;
      totalFeesReal += depositFeeAmount / inflationIndex;

      const returnPhase = findPhase(s.returnPhases, age);
      const marketAnnualNominal = normalizedAnnualRate(
        returnPhase?.annualReturn || 0,
        returnPhase?.returnType || 'real',
        inflationAnnual
      );
      let monthlyPortfolioReturn = annualToMonthly(marketAnnualNominal);

      if (s.investment?.blendProtected) {
        const wProtected = clamp(Number(s.investment.protectedWeight) || 0, 0, 1);
        const protectedReal = Number(s.investment.protectedRealReturn) || 0;
        const protectedNominal = realToNominal(protectedReal, inflationAnnual);
        const protectedMonthly = annualToMonthly(protectedNominal);
        const marketMonthly = annualToMonthly(marketAnnualNominal);
        monthlyPortfolioReturn = wProtected * protectedMonthly + (1 - wProtected) * marketMonthly;
      }

      const gain = balance * monthlyPortfolioReturn;
      balance += gain;
      totalInvestmentGainNominal += gain;

      const assetFeeAmount = balance * monthlyAssetFee;
      balance -= assetFeeAmount;
      totalFeesNominal += assetFeeAmount;
      totalFeesReal += assetFeeAmount / inflationIndex;

      // Apply salary growth at month end.
      salary *= 1 + salaryMonthlyGrowth;

      // If a break has just ended, apply the configured restart rule.
      const nextAge = currentAge + (m + 1) / 12;
      const nextBreak = inBreak(s.careerBreaks, nextAge);
      if (activeBreak && !nextBreak) {
        if (activeBreak.salaryResumeMode === 'previous' && salaryAtBreakStart != null) {
          salary = salaryAtBreakStart;
        } else if (activeBreak.salaryResumeMode === 'custom') {
          salary = Math.max(0, Number(activeBreak.customRestartSalary) || 0);
        }
        lastBreakId = null;
        salaryAtBreakStart = null;
      }

      if ((m + 1) % 12 === 0 || m === months - 1) snapshot(m + 1);
    }

    const coefficient = Math.max(1, Number(s.retirement.coefficient) || 200);
    const retirementBalanceNominal = balance;
    const retirementBalanceReal = balance / inflationIndex;
    const monthlyPensionNominal = retirementBalanceNominal / coefficient;
    const monthlyPensionReal = retirementBalanceReal / coefficient;
    const startBalance = Math.max(0, Number(s.profile.currentBalance) || 0);
    const investmentGrowthReal = retirementBalanceReal - startBalance - totalContributionsReal + totalFeesReal;

    return {
      months,
      snapshots,
      inflationIndex,
      retirementBalanceNominal,
      retirementBalanceReal,
      monthlyPensionNominal,
      monthlyPensionReal,
      totalContributionsNominal,
      totalContributionsReal,
      totalFeesNominal,
      totalFeesReal,
      totalInvestmentGainNominal,
      investmentGrowthReal,
      finalSalaryNominal: salary,
      finalSalaryReal: salary / inflationIndex,
    };
  }

  function pensionAtCoefficient(result, coefficient, real = true) {
    const balance = real ? result.retirementBalanceReal : result.retirementBalanceNominal;
    return balance / Math.max(1, Number(coefficient) || 1);
  }

  function cloneScenario(s) {
    return JSON.parse(JSON.stringify(s));
  }

  function retirementAgeSeries(scenario, minAge, maxAge) {
    const rows = [];
    for (let age = minAge; age <= maxAge; age++) {
      if (age <= Number(scenario.profile.currentAge)) continue;
      const copy = cloneScenario(scenario);
      copy.retirement.retirementAge = age;
      // Extend final phases automatically if needed.
      if (copy.salaryPhases?.length) {
        copy.salaryPhases[copy.salaryPhases.length - 1].endAge = Math.max(age, copy.salaryPhases[copy.salaryPhases.length - 1].endAge);
      }
      if (copy.returnPhases?.length) {
        copy.returnPhases[copy.returnPhases.length - 1].endAge = Math.max(age, copy.returnPhases[copy.returnPhases.length - 1].endAge);
      }
      try {
        const r = project(copy);
        rows.push({ age, realBalance: r.retirementBalanceReal, realPension: r.monthlyPensionReal, nominalBalance: r.retirementBalanceNominal, nominalPension: r.monthlyPensionNominal });
      } catch (_) {}
    }
    return rows;
  }

  function compareScenarios(a, b) {
    const ra = project(a);
    const rb = project(b);
    return {
      balanceRealDelta: rb.retirementBalanceReal - ra.retirementBalanceReal,
      pensionRealDelta: rb.monthlyPensionReal - ra.monthlyPensionReal,
      balanceNominalDelta: rb.retirementBalanceNominal - ra.retirementBalanceNominal,
      pensionNominalDelta: rb.monthlyPensionNominal - ra.monthlyPensionNominal,
    };
  }

  return {
    clamp,
    annualToMonthly,
    realToNominal,
    nominalToReal,
    project,
    pensionAtCoefficient,
    retirementAgeSeries,
    compareScenarios,
    cloneScenario,
  };
});
