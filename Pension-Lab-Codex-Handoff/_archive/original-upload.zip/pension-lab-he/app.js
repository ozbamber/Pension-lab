(function () {
  'use strict';
  const E = window.PensionEngine;
  const $ = (id) => document.getElementById(id);
  const storageKey = 'pension-lab-he-state-v1';
  const scenariosKey = 'pension-lab-he-scenarios-v1';
  const moneyModeKey = 'pension-lab-he-money-mode-v1';

  const exampleScenario = {
    profile: { currentAge: 35, currentBalance: 250000, monthlySalary: 20000, pensionableSalary: 20000 },
    inflation: { annualRate: 0.025 },
    salaryPhases: [
      { id: cryptoId(), startAge: 35, endAge: 45, annualGrowth: 0.04, growthType: 'nominal' },
      { id: cryptoId(), startAge: 45, endAge: 67, annualGrowth: 0.025, growthType: 'nominal' },
    ],
    contribution: {
      mode: 'percent', fixedAmount: 4500, fixedGrowsWithSalary: true,
      employeeRate: 0.06, employerRate: 0.065, severanceRate: 0.0833, pensionableSalaryLimit: 0,
    },
    returnPhases: [
      { id: cryptoId(), startAge: 35, endAge: 50, annualReturn: 0.055, returnType: 'real' },
      { id: cryptoId(), startAge: 50, endAge: 67, annualReturn: 0.045, returnType: 'real' },
    ],
    investment: { blendProtected: false, protectedWeight: 0.30, protectedRealReturn: 0.0515 },
    careerBreaks: [],
    fees: { annualBalanceFee: 0.005, depositFee: 0 },
    retirement: { retirementAge: 67, coefficient: 200 },
  };

  let state = loadJSON(storageKey, exampleScenario);
  let savedScenarios = loadJSON(scenariosKey, []);
  let moneyMode = localStorage.getItem(moneyModeKey) || 'real';
  let lastResult = null;
  let lastChanged = 'initial';

  function cryptoId() { return Math.random().toString(36).slice(2, 10); }
  function deepClone(v) { return JSON.parse(JSON.stringify(v)); }
  function loadJSON(key, fallback) {
    try { const v = JSON.parse(localStorage.getItem(key)); return v || deepClone(fallback); } catch (_) { return deepClone(fallback); }
  }
  function saveState() { localStorage.setItem(storageKey, JSON.stringify(state)); }
  function pct(v, digits = 1) { return (Number(v || 0) * 100).toFixed(digits); }
  function num(id) { return Number($(id).value) || 0; }
  function setValue(id, v) { $(id).value = v; }
  function formatMoney(value, compact = true) {
    const abs = Math.abs(value || 0);
    const sign = value < 0 ? '-' : '';
    if (compact && abs >= 1000000) return `${sign}₪${(abs / 1000000).toFixed(abs >= 10000000 ? 1 : 2)} מיליון`;
    if (compact && abs >= 1000) return `${sign}₪${(abs / 1000).toFixed(abs >= 100000 ? 0 : 1)} אלף`;
    return new Intl.NumberFormat('he-IL', { style:'currency', currency:'ILS', maximumFractionDigits:0 }).format(value || 0);
  }
  function formatMonthly(value) { return `${formatMoney(value, false)} לחודש`; }
  function toast(text) { const el=$('toast'); el.textContent=text; el.classList.add('show'); clearTimeout(toast.t); toast.t=setTimeout(()=>el.classList.remove('show'),2200); }

  function normalizeState() {
    const ca = E.clamp(Number(state.profile.currentAge) || 18, 18, 70);
    const ra = E.clamp(Number(state.retirement.retirementAge) || ca + 1, ca + 1, 80);
    state.profile.currentAge = ca;
    state.retirement.retirementAge = ra;
    state.salaryPhases = normalizePhases(state.salaryPhases, ca, ra, 'salary');
    state.returnPhases = normalizePhases(state.returnPhases, ca, ra, 'return');
    state.careerBreaks = (state.careerBreaks || []).filter(b => Number(b.startAge) >= ca && Number(b.startAge) < ra);
  }

  function normalizePhases(phases, currentAge, retirementAge, kind) {
    let arr = Array.isArray(phases) ? deepClone(phases) : [];
    arr = arr.filter(p => Number(p.endAge) > currentAge && Number(p.startAge) < retirementAge)
      .map(p => ({...p, startAge: Math.max(currentAge, Number(p.startAge)), endAge: Math.min(retirementAge, Number(p.endAge))}))
      .sort((a,b)=>a.startAge-b.startAge);
    if (!arr.length) {
      return kind === 'salary'
        ? [{id:cryptoId(), startAge:currentAge, endAge:retirementAge, annualGrowth:0.025, growthType:'nominal'}]
        : [{id:cryptoId(), startAge:currentAge, endAge:retirementAge, annualReturn:0.05, returnType:'real'}];
    }
    arr[0].startAge = currentAge;
    for (let i=1;i<arr.length;i++) arr[i].startAge = arr[i-1].endAge;
    arr[arr.length-1].endAge = retirementAge;
    return arr;
  }

  function renderForm() {
    normalizeState();
    setValue('currentAge', state.profile.currentAge);
    setValue('retirementAge', state.retirement.retirementAge);
    setValue('currentBalance', Math.round(state.profile.currentBalance));
    setValue('monthlySalary', Math.round(state.profile.monthlySalary));
    setValue('pensionableSalary', Math.round(state.profile.pensionableSalary));
    setValue('employeeRate', pct(state.contribution.employeeRate));
    setValue('employerRate', pct(state.contribution.employerRate));
    setValue('severanceRate', pct(state.contribution.severanceRate));
    setValue('fixedContribution', Math.round(state.contribution.fixedAmount));
    $('fixedGrowsWithSalary').checked = !!state.contribution.fixedGrowsWithSalary;
    setContributionModeUI();
    setValue('inflation', pct(state.inflation.annualRate));
    setValue('inflationRange', pct(state.inflation.annualRate));
    $('blendProtected').checked = !!state.investment.blendProtected;
    setValue('protectedWeight', pct(state.investment.protectedWeight,0));
    setValue('protectedReturn', pct(state.investment.protectedRealReturn,2));
    $('protectedFields').classList.toggle('hidden', !state.investment.blendProtected);
    setValue('annualBalanceFee', pct(state.fees.annualBalanceFee,2));
    setValue('depositFee', pct(state.fees.depositFee,2));
    setValue('coefficient', state.retirement.coefficient);
    setValue('coefficientRange', state.retirement.coefficient);
    $('yearsRemainingHint').textContent = `${(state.retirement.retirementAge-state.profile.currentAge).toFixed(0)} שנים עד הפרישה`;
    renderSalaryPhases();
    renderReturnPhases();
    renderCareerBreaks();
    renderMoneyMode();
  }

  function setContributionModeUI() {
    const percent = state.contribution.mode === 'percent';
    $('contributionModePercent').classList.toggle('active', percent);
    $('contributionModeFixed').classList.toggle('active', !percent);
    $('contributionPercentFields').classList.toggle('hidden', !percent);
    $('contributionFixedFields').classList.toggle('hidden', percent);
  }

  function phaseCard(phase, index, kind) {
    const isSalary = kind === 'salary';
    const rate = isSalary ? phase.annualGrowth : phase.annualReturn;
    const type = isSalary ? phase.growthType : phase.returnType;
    const noun = isSalary ? 'שכר' : 'תשואה';
    const typeOptions = isSalary
      ? `<option value="nominal" ${type==='nominal'?'selected':''}>נומינלי</option><option value="real" ${type==='real'?'selected':''}>ריאלי</option>`
      : `<option value="real" ${type==='real'?'selected':''}>ריאלי</option><option value="nominal" ${type==='nominal'?'selected':''}>נומינלי</option>`;
    return `<div class="phase-card" data-phase-id="${phase.id}">
      <div class="phase-head"><strong>שלב ${noun} ${index+1}</strong><button class="icon-btn" data-remove-${kind}="${phase.id}" title="מחק">✕</button></div>
      <div class="phase-grid">
        <label class="mini-field">מגיל<input data-${kind}-field="startAge" data-id="${phase.id}" type="number" value="${phase.startAge}" min="18" max="80" step="1"></label>
        <label class="mini-field">עד גיל<input data-${kind}-field="endAge" data-id="${phase.id}" type="number" value="${phase.endAge}" min="19" max="80" step="1"></label>
        <label class="mini-field">שינוי שנתי (%)<input data-${kind}-field="rate" data-id="${phase.id}" type="number" value="${(rate*100).toFixed(2)}" min="-20" max="20" step="0.1"></label>
        <label class="mini-field">סוג<select data-${kind}-field="type" data-id="${phase.id}">${typeOptions}</select></label>
      </div>
    </div>`;
  }

  function renderSalaryPhases() { $('salaryPhases').innerHTML = state.salaryPhases.map((p,i)=>phaseCard(p,i,'salary')).join(''); }
  function renderReturnPhases() { $('returnPhases').innerHTML = state.returnPhases.map((p,i)=>phaseCard(p,i,'return')).join(''); }

  function renderCareerBreaks() {
    const html = (state.careerBreaks || []).map((b,i)=>`<div class="break-card">
      <div class="phase-head"><strong>הפסקה ${i+1}</strong><button class="icon-btn" data-remove-break="${b.id}">✕</button></div>
      <div class="break-grid">
        <label class="mini-field">מתחילה בגיל<input data-break-field="startAge" data-id="${b.id}" type="number" value="${b.startAge}" min="${state.profile.currentAge}" max="${state.retirement.retirementAge-0.1}" step="0.5"></label>
        <label class="mini-field">משך (חודשים)<input data-break-field="durationMonths" data-id="${b.id}" type="number" value="${b.durationMonths}" min="1" max="120" step="1"></label>
        <label class="mini-field">הפקדה חודשית בזמן ההפסקה<input data-break-field="contributionDuringBreak" data-id="${b.id}" type="number" value="${b.contributionDuringBreak||0}" min="0" step="100"></label>
        <label class="mini-field">שכר בחזרה<select data-break-field="salaryResumeMode" data-id="${b.id}">
          <option value="projected" ${b.salaryResumeMode==='projected'?'selected':''}>מסלול שכר מקורי</option>
          <option value="previous" ${b.salaryResumeMode==='previous'?'selected':''}>השכר האחרון</option>
          <option value="custom" ${b.salaryResumeMode==='custom'?'selected':''}>שכר חדש</option>
        </select></label>
      </div>
      ${b.salaryResumeMode==='custom'?`<label class="mini-field" style="margin-top:8px">שכר חזרה<input data-break-field="customRestartSalary" data-id="${b.id}" type="number" value="${b.customRestartSalary||0}" min="0" step="500"></label>`:''}
    </div>`).join('');
    $('careerBreaks').innerHTML = html || '<p class="section-help">אין כרגע הפסקות עבודה בתרחיש.</p>';
  }

  function readBasicInputs() {
    const oldAge = state.profile.currentAge;
    const oldRet = state.retirement.retirementAge;
    state.profile.currentAge = E.clamp(num('currentAge'), 18, 70);
    state.retirement.retirementAge = E.clamp(num('retirementAge'), state.profile.currentAge+1, 80);
    state.profile.currentBalance = Math.max(0, num('currentBalance'));
    state.profile.monthlySalary = Math.max(0, num('monthlySalary'));
    state.profile.pensionableSalary = Math.max(0, num('pensionableSalary'));
    state.contribution.employeeRate = num('employeeRate')/100;
    state.contribution.employerRate = num('employerRate')/100;
    state.contribution.severanceRate = num('severanceRate')/100;
    state.contribution.fixedAmount = Math.max(0, num('fixedContribution'));
    state.contribution.fixedGrowsWithSalary = $('fixedGrowsWithSalary').checked;
    state.inflation.annualRate = num('inflation')/100;
    state.investment.blendProtected = $('blendProtected').checked;
    state.investment.protectedWeight = num('protectedWeight')/100;
    state.investment.protectedRealReturn = num('protectedReturn')/100;
    state.fees.annualBalanceFee = num('annualBalanceFee')/100;
    state.fees.depositFee = num('depositFee')/100;
    state.retirement.coefficient = Math.max(1, num('coefficient'));
    if (oldAge !== state.profile.currentAge || oldRet !== state.retirement.retirementAge) {
      normalizeState();
      renderSalaryPhases(); renderReturnPhases(); renderCareerBreaks();
    }
  }

  function currentContribution() {
    if (state.contribution.mode === 'fixed') return state.contribution.fixedAmount;
    const pensionable = Math.min(state.profile.pensionableSalary, state.contribution.pensionableSalaryLimit > 0 ? state.contribution.pensionableSalaryLimit : Infinity);
    return pensionable * (state.contribution.employeeRate + state.contribution.employerRate + state.contribution.severanceRate);
  }

  function updateAll() {
    readBasicInputs();
    saveState();
    $('yearsRemainingHint').textContent = `${(state.retirement.retirementAge-state.profile.currentAge).toFixed(0)} שנים עד הפרישה`;
    $('currentContributionLabel').textContent = formatMoney(currentContribution(), false);
    try {
      lastResult = E.project(state);
      renderResults(lastResult);
      renderCoefficientSensitivity(lastResult);
      drawBalanceChart(lastResult);
      renderRetirementExplorer();
      renderExplain(lastResult);
      renderInsight(lastResult);
      renderSavedScenarios();
    } catch (err) {
      toast(err.message || 'יש בעיה בהנחות');
    }
  }

  function renderResults(r) {
    const real = moneyMode === 'real';
    const bal = real ? r.retirementBalanceReal : r.retirementBalanceNominal;
    const pension = real ? r.monthlyPensionReal : r.monthlyPensionNominal;
    const contrib = real ? r.totalContributionsReal : r.totalContributionsNominal;
    const fees = real ? r.totalFeesReal : r.totalFeesNominal;
    const growth = real ? r.investmentGrowthReal : (r.retirementBalanceNominal - state.profile.currentBalance - r.totalContributionsNominal + r.totalFeesNominal);
    $('headlinePension').textContent = formatMoney(pension, false);
    $('headlinePensionSub').textContent = `לפני מס · מקדם ${state.retirement.coefficient}`;
    $('headlineBalance').textContent = formatMoney(bal, true);
    $('headlineBalanceSub').textContent = real ? 'בשקלים של היום' : 'בשקלים עתידיים';
    const years = state.retirement.retirementAge - state.profile.currentAge;
    $('yearsToRetirement').textContent = `${years} שנים`;
    $('retirementAgeText').textContent = `פרישה בגיל ${state.retirement.retirementAge}`;
    $('contribResult').textContent = formatMoney(contrib, true);
    $('growthResult').textContent = formatMoney(growth, true);
    $('feesResult').textContent = formatMoney(fees, true);
    $('chartModeLabel').textContent = real ? 'בשקלים של היום' : 'בשקלים עתידיים';
    $('chartFinalLabel').textContent = `בפרישה: ${formatMoney(bal, true)}`;
  }

  function renderCoefficientSensitivity(r) {
    const real = moneyMode === 'real';
    const selected = Number(state.retirement.coefficient);
    const coeffs = Array.from(new Set([180,200,220,240,selected])).sort((a,b)=>a-b).slice(0,5);
    $('coefficientSensitivity').innerHTML = coeffs.map(c=>`<div><span>מקדם ${c}</span><strong>${formatMoney(E.pensionAtCoefficient(r,c,real),false)}</strong></div>`).join('');
  }

  function renderExplain(r) {
    const real = moneyMode === 'real';
    const start = state.profile.currentBalance;
    const contrib = real ? r.totalContributionsReal : r.totalContributionsNominal;
    const fees = real ? r.totalFeesReal : r.totalFeesNominal;
    const final = real ? r.retirementBalanceReal : r.retirementBalanceNominal;
    const growth = final - start - contrib + fees;
    $('explainResult').innerHTML = [
      ['יתרה התחלתית', start], ['הפקדות נטו', contrib], ['צמיחה מהשקעות', growth], ['דמי ניהול', -fees]
    ].map(([label,v])=>`<div class="explain-item"><span>${label}</span><strong>${formatMoney(v,true)}</strong></div>`).join('');
  }

  function renderInsight(r) {
    const years = state.retirement.retirementAge-state.profile.currentAge;
    const breakMonths = (state.careerBreaks||[]).reduce((s,b)=>s+Number(b.durationMonths||0),0);
    const firstReturn = state.returnPhases[0]?.annualReturn || 0;
    let title = `יש לך ${years} שנים של צבירה וריבית דריבית`;
    let text = `בהנחות הנוכחיות, כל שינוי קטן בתשואה או בגיל הפרישה פועל לאורך תקופה ארוכה ולכן ההשפעה המצטברת יכולה להיות משמעותית.`;
    if (lastChanged === 'retirement') {
      const next = deepClone(state); next.retirement.retirementAge = Math.min(80, state.retirement.retirementAge+1);
      if (next.retirement.retirementAge > state.retirement.retirementAge) {
        const nr = E.project(next); const d = nr.monthlyPensionReal-r.monthlyPensionReal;
        title = `עוד שנת עבודה אחת מוסיפה כ־${formatMoney(d,false)} לקצבה החודשית`;
        text = 'ההשפעה מגיעה משילוב של עוד הפקדות, עוד זמן לצמיחה והשארת הכסף מושקע שנה נוספת.';
      }
    } else if (breakMonths > 0) {
      const noBreak = deepClone(state); noBreak.careerBreaks=[]; const nb=E.project(noBreak);
      const d=nb.monthlyPensionReal-r.monthlyPensionReal;
      title = `הפסקות העבודה בתרחיש עולות כ־${formatMoney(d,false)} לחודש בפרישה`;
      text = 'הפער כולל גם את ההפקדות שלא בוצעו וגם את הצמיחה העתידית שאותן הפקדות היו יכולות לצבור.';
    } else if (firstReturn >= .06) {
      title = 'התרחיש נשען על תשואה יחסית גבוהה';
      text = 'כדאי לשמור לידו גם תרחיש של 4%–5% ריאלי כדי לראות כמה מהתוצאה תלויה בהנחת התשואה.';
    }
    $('insightTitle').textContent=title; $('insightText').textContent=text;
  }

  function renderRetirementExplorer() {
    const min = Math.max(state.profile.currentAge+1, Math.max(55, state.retirement.retirementAge-4));
    const max = Math.min(80, Math.max(state.retirement.retirementAge+4, min+4));
    const rows = E.retirementAgeSeries(state, min, max);
    drawRetirementChart(rows);
    const picked = rows.filter((_,i)=>i===0 || i===rows.length-1 || rows[i].age===state.retirement.retirementAge || i%2===0).slice(0,8);
    $('retirementAgeTable').innerHTML = picked.map(r=>`<div><span>גיל ${r.age}</span><strong>${formatMoney(moneyMode==='real'?r.realPension:r.nominalPension,false)}</strong></div>`).join('');
  }

  function setupCanvas(canvas) {
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const rect = canvas.getBoundingClientRect();
    const w = Math.max(320, rect.width);
    const h = Number(canvas.getAttribute('height')) || 280;
    canvas.width = w*dpr; canvas.height = h*dpr;
    const ctx=canvas.getContext('2d'); ctx.scale(dpr,dpr); return {ctx,w,h};
  }

  function drawBalanceChart(r) {
    const canvas=$('balanceChart'), {ctx,w,h}=setupCanvas(canvas);
    const pad={t:24,r:58,b:34,l:18}; const plotW=w-pad.r-pad.l, plotH=h-pad.t-pad.b;
    const data=r.snapshots.map(s=>({x:s.age,y:moneyMode==='real'?s.realBalance:s.nominalBalance}));
    const maxY=Math.max(1,...data.map(d=>d.y))*1.08, minX=data[0].x, maxX=data[data.length-1].x;
    ctx.clearRect(0,0,w,h); ctx.font='11px Arial'; ctx.textAlign='right'; ctx.textBaseline='middle';
    for(let i=0;i<=4;i++){
      const y=pad.t+plotH*i/4; ctx.strokeStyle='#e7eaee'; ctx.lineWidth=1; ctx.beginPath();ctx.moveTo(pad.l,y);ctx.lineTo(w-pad.r,y);ctx.stroke();
      ctx.fillStyle='#7b828c'; ctx.fillText(formatMoney(maxY*(1-i/4),true),w-4,y);
    }
    const xFn=x=>pad.l+(x-minX)/(maxX-minX||1)*plotW, yFn=y=>pad.t+plotH-(y/maxY)*plotH;
    const grad=ctx.createLinearGradient(0,pad.t,0,h-pad.b); grad.addColorStop(0,'rgba(31,95,80,.22)'); grad.addColorStop(1,'rgba(31,95,80,0)');
    ctx.beginPath(); data.forEach((d,i)=>i?ctx.lineTo(xFn(d.x),yFn(d.y)):ctx.moveTo(xFn(d.x),yFn(d.y))); ctx.lineTo(xFn(data[data.length-1].x),h-pad.b);ctx.lineTo(xFn(data[0].x),h-pad.b);ctx.closePath();ctx.fillStyle=grad;ctx.fill();
    ctx.beginPath(); data.forEach((d,i)=>i?ctx.lineTo(xFn(d.x),yFn(d.y)):ctx.moveTo(xFn(d.x),yFn(d.y))); ctx.strokeStyle='#1f5f50';ctx.lineWidth=3;ctx.stroke();
    ctx.fillStyle='#707781'; ctx.textAlign='center';
    const ticks=4; for(let i=0;i<=ticks;i++){ const age=minX+(maxX-minX)*i/ticks; ctx.fillText(`גיל ${Math.round(age)}`,xFn(age),h-12); }
    const last=data[data.length-1]; ctx.fillStyle='#1f5f50';ctx.beginPath();ctx.arc(xFn(last.x),yFn(last.y),5,0,Math.PI*2);ctx.fill();
  }

  function drawRetirementChart(rows) {
    const canvas=$('retirementChart'), {ctx,w,h}=setupCanvas(canvas); const pad={t:20,r:18,b:34,l:18}; const plotW=w-pad.r-pad.l,plotH=h-pad.t-pad.b;
    const vals=rows.map(r=>moneyMode==='real'?r.realPension:r.nominalPension); const maxY=Math.max(1,...vals)*1.1; const minAge=rows[0]?.age||0,maxAge=rows[rows.length-1]?.age||1;
    ctx.clearRect(0,0,w,h); ctx.font='11px Arial';ctx.textBaseline='middle';
    for(let i=0;i<=4;i++){const y=pad.t+plotH*i/4;ctx.strokeStyle='#e7eaee';ctx.beginPath();ctx.moveTo(pad.l,y);ctx.lineTo(w-pad.r,y);ctx.stroke();ctx.fillStyle='#7b828c';ctx.textAlign='left';ctx.fillText(formatMoney(maxY*(1-i/4),true),pad.l,y-8);}
    const xFn=x=>pad.l+(x-minAge)/(maxAge-minAge||1)*plotW,yFn=y=>pad.t+plotH-(y/maxY)*plotH;
    ctx.beginPath();rows.forEach((r,i)=>{const x=xFn(r.age),y=yFn(vals[i]);i?ctx.lineTo(x,y):ctx.moveTo(x,y)});ctx.strokeStyle='#315b7d';ctx.lineWidth=3;ctx.stroke();
    rows.forEach((r,i)=>{ctx.fillStyle=r.age===state.retirement.retirementAge?'#1f5f50':'#315b7d';ctx.beginPath();ctx.arc(xFn(r.age),yFn(vals[i]),r.age===state.retirement.retirementAge?5:3,0,Math.PI*2);ctx.fill();});
    ctx.fillStyle='#707781';ctx.textAlign='center';rows.forEach((r,i)=>{if(i===0||i===rows.length-1||r.age===state.retirement.retirementAge)ctx.fillText(`גיל ${r.age}`,xFn(r.age),h-12)});
  }

  function renderMoneyMode() {
    document.querySelectorAll('[data-money-mode]').forEach(b=>b.classList.toggle('active',b.dataset.moneyMode===moneyMode));
  }

  function renderSavedScenarios() {
    if (!savedScenarios.length) {
      $('savedScenarios').innerHTML='<p class="section-help">עדיין אין תרחישים שמורים. לחצו “שמור תרחיש” כדי להתחיל להשוות.</p>';
      $('comparisonTableWrap').innerHTML=''; return;
    }
    $('savedScenarios').innerHTML=savedScenarios.map((s,i)=>{
      let r; try{r=E.project(s.state)}catch(_){return ''}
      return `<article class="scenario-card"><h3>${escapeHtml(s.name)}</h3><div class="scenario-metrics">
        <div><span>גיל פרישה</span><strong>${s.state.retirement.retirementAge}</strong></div>
        <div><span>צבירה ריאלית</span><strong>${formatMoney(r.retirementBalanceReal,true)}</strong></div>
        <div><span>קצבה ריאלית</span><strong>${formatMoney(r.monthlyPensionReal,false)}</strong></div>
      </div><div class="scenario-actions"><button class="load" data-load-scenario="${i}">טען</button><button class="delete" data-delete-scenario="${i}">מחק</button></div></article>`;
    }).join('');
    const subset=savedScenarios.slice(0,4);
    const rows=subset.map(s=>({s,r:E.project(s.state)}));
    $('comparisonTableWrap').innerHTML=`<table><thead><tr><th>מדד</th>${rows.map(x=>`<th>${escapeHtml(x.s.name)}</th>`).join('')}</tr></thead><tbody>
      <tr><td>גיל נוכחי</td>${rows.map(x=>`<td>${x.s.state.profile.currentAge}</td>`).join('')}</tr>
      <tr><td>גיל פרישה</td>${rows.map(x=>`<td>${x.s.state.retirement.retirementAge}</td>`).join('')}</tr>
      <tr><td>צבירה בשקלים של היום</td>${rows.map(x=>`<td>${formatMoney(x.r.retirementBalanceReal,true)}</td>`).join('')}</tr>
      <tr><td>קצבה חודשית ריאלית</td>${rows.map(x=>`<td>${formatMoney(x.r.monthlyPensionReal,false)}</td>`).join('')}</tr>
      <tr><td>מקדם</td>${rows.map(x=>`<td>${x.s.state.retirement.coefficient}</td>`).join('')}</tr>
    </tbody></table>`;
  }

  function escapeHtml(str){return String(str).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}

  function applyPreset(name) {
    const ca=state.profile.currentAge,ra=state.retirement.retirementAge;
    if(name==='conservative'){
      state.returnPhases=[{id:cryptoId(),startAge:ca,endAge:ra,annualReturn:.04,returnType:'real'}]; state.retirement.coefficient=230;
    } else if(name==='growth') {
      state.returnPhases=[{id:cryptoId(),startAge:ca,endAge:ra,annualReturn:.06,returnType:'real'}]; state.retirement.coefficient=190;
    } else {
      state.returnPhases=[{id:cryptoId(),startAge:ca,endAge:Math.min(ra,ca+15),annualReturn:.055,returnType:'real'}];
      if(ca+15<ra) state.returnPhases.push({id:cryptoId(),startAge:ca+15,endAge:ra,annualReturn:.045,returnType:'real'});
      state.retirement.coefficient=200;
    }
    document.querySelectorAll('[data-preset]').forEach(b=>b.classList.toggle('active',b.dataset.preset===name));
    renderForm(); updateAll();
  }

  // Basic field listeners.
  ['currentAge','retirementAge','currentBalance','monthlySalary','pensionableSalary','employeeRate','employerRate','severanceRate','fixedContribution','annualBalanceFee','depositFee'].forEach(id=>{
    $(id).addEventListener('input',()=>{ lastChanged=id==='retirementAge'?'retirement':'input'; updateAll(); });
  });
  $('fixedGrowsWithSalary').addEventListener('change',updateAll);
  $('inflation').addEventListener('input',()=>{setValue('inflationRange',$('inflation').value);lastChanged='inflation';updateAll();});
  $('inflationRange').addEventListener('input',()=>{setValue('inflation',$('inflationRange').value);lastChanged='inflation';updateAll();});
  $('coefficient').addEventListener('input',()=>{setValue('coefficientRange',$('coefficient').value);lastChanged='coefficient';updateAll();});
  $('coefficientRange').addEventListener('input',()=>{setValue('coefficient',$('coefficientRange').value);lastChanged='coefficient';updateAll();});
  $('blendProtected').addEventListener('change',()=>{$('protectedFields').classList.toggle('hidden',!$('blendProtected').checked);lastChanged='investment';updateAll();});
  ['protectedWeight','protectedReturn'].forEach(id=>$(id).addEventListener('input',()=>{lastChanged='investment';updateAll();}));
  $('contributionModePercent').addEventListener('click',()=>{state.contribution.mode='percent';setContributionModeUI();lastChanged='contribution';updateAll();});
  $('contributionModeFixed').addEventListener('click',()=>{state.contribution.mode='fixed';setContributionModeUI();lastChanged='contribution';updateAll();});

  document.addEventListener('input',(e)=>{
    const t=e.target;
    if(t.dataset.salaryField){
      const p=state.salaryPhases.find(x=>x.id===t.dataset.id); if(!p)return;
      if(t.dataset.salaryField==='startAge')p.startAge=Number(t.value);
      if(t.dataset.salaryField==='endAge')p.endAge=Number(t.value);
      if(t.dataset.salaryField==='rate')p.annualGrowth=Number(t.value)/100;
      lastChanged='salary'; saveState(); try{lastResult=E.project(state);renderResults(lastResult);renderCoefficientSensitivity(lastResult);drawBalanceChart(lastResult);renderRetirementExplorer();renderExplain(lastResult);renderInsight(lastResult);}catch(_){}
    }
    if(t.dataset.returnField){
      const p=state.returnPhases.find(x=>x.id===t.dataset.id); if(!p)return;
      if(t.dataset.returnField==='startAge')p.startAge=Number(t.value);
      if(t.dataset.returnField==='endAge')p.endAge=Number(t.value);
      if(t.dataset.returnField==='rate')p.annualReturn=Number(t.value)/100;
      lastChanged='return';saveState();try{lastResult=E.project(state);renderResults(lastResult);renderCoefficientSensitivity(lastResult);drawBalanceChart(lastResult);renderRetirementExplorer();renderExplain(lastResult);renderInsight(lastResult);}catch(_){}
    }
    if(t.dataset.breakField){
      const b=state.careerBreaks.find(x=>x.id===t.dataset.id);if(!b)return;
      const f=t.dataset.breakField;b[f]=(f==='salaryResumeMode')?t.value:Number(t.value);
      lastChanged='break';saveState();if(f==='salaryResumeMode') renderCareerBreaks();updateAll();
    }
  });
  document.addEventListener('change',(e)=>{
    const t=e.target;
    if(t.dataset.salaryField==='type'){const p=state.salaryPhases.find(x=>x.id===t.dataset.id);p.growthType=t.value;updateAll();}
    if(t.dataset.returnField==='type'){const p=state.returnPhases.find(x=>x.id===t.dataset.id);p.returnType=t.value;updateAll();}
  });
  document.addEventListener('click',(e)=>{
    const b=e.target.closest('button');if(!b)return;
    if(b.dataset.removeSalary){state.salaryPhases=state.salaryPhases.filter(p=>p.id!==b.dataset.removeSalary);normalizeState();renderSalaryPhases();updateAll();}
    if(b.dataset.removeReturn){state.returnPhases=state.returnPhases.filter(p=>p.id!==b.dataset.removeReturn);normalizeState();renderReturnPhases();updateAll();}
    if(b.dataset.removeBreak){state.careerBreaks=state.careerBreaks.filter(x=>x.id!==b.dataset.removeBreak);renderCareerBreaks();updateAll();}
    if(b.dataset.moneyMode){moneyMode=b.dataset.moneyMode;localStorage.setItem(moneyModeKey,moneyMode);renderMoneyMode();updateAll();}
    if(b.dataset.preset) applyPreset(b.dataset.preset);
    if(b.dataset.loadScenario!=null){state=deepClone(savedScenarios[Number(b.dataset.loadScenario)].state);renderForm();updateAll();toast('התרחיש נטען');window.scrollTo({top:0,behavior:'smooth'});}
    if(b.dataset.deleteScenario!=null){savedScenarios.splice(Number(b.dataset.deleteScenario),1);localStorage.setItem(scenariosKey,JSON.stringify(savedScenarios));renderSavedScenarios();}
  });

  $('addSalaryPhase').addEventListener('click',()=>{
    const last=state.salaryPhases[state.salaryPhases.length-1]; const mid=Math.max(state.profile.currentAge+1, Math.round((last.startAge+last.endAge)/2));
    if(last.endAge-last.startAge<2)return toast('אין מספיק מרווח להוספת שלב');
    const oldEnd=last.endAge;last.endAge=mid;state.salaryPhases.push({id:cryptoId(),startAge:mid,endAge:oldEnd,annualGrowth:last.annualGrowth,growthType:last.growthType});renderSalaryPhases();updateAll();
  });
  $('addReturnPhase').addEventListener('click',()=>{
    const last=state.returnPhases[state.returnPhases.length-1]; const mid=Math.max(state.profile.currentAge+1, Math.round((last.startAge+last.endAge)/2));
    if(last.endAge-last.startAge<2)return toast('אין מספיק מרווח להוספת שלב');
    const oldEnd=last.endAge;last.endAge=mid;state.returnPhases.push({id:cryptoId(),startAge:mid,endAge:oldEnd,annualReturn:last.annualReturn,returnType:last.returnType});renderReturnPhases();updateAll();
  });
  $('addCareerBreak').addEventListener('click',()=>{
    const start=Math.min(state.retirement.retirementAge-1,state.profile.currentAge+5);state.careerBreaks.push({id:cryptoId(),startAge:start,durationMonths:24,contributionDuringBreak:0,salaryResumeMode:'projected',customRestartSalary:state.profile.monthlySalary});renderCareerBreaks();updateAll();
  });
  $('saveScenarioBtn').addEventListener('click',()=>{
    const defaultName=`תרחיש ${savedScenarios.length+1} · פרישה ${state.retirement.retirementAge}`; const name=window.prompt('שם לתרחיש',defaultName); if(!name)return;
    savedScenarios.push({name,state:deepClone(state),savedAt:new Date().toISOString()});localStorage.setItem(scenariosKey,JSON.stringify(savedScenarios));renderSavedScenarios();toast('התרחיש נשמר בדפדפן');
  });
  $('clearScenariosBtn').addEventListener('click',()=>{if(window.confirm('למחוק את כל התרחישים השמורים?')){savedScenarios=[];localStorage.setItem(scenariosKey,'[]');renderSavedScenarios();}});
  $('resetBtn').addEventListener('click',()=>{if(window.confirm('לאפס את כל ההנחות לנתוני הדוגמה?')){state=deepClone(exampleScenario);localStorage.removeItem(storageKey);renderForm();updateAll();}});
  window.addEventListener('resize',()=>{if(lastResult){drawBalanceChart(lastResult);renderRetirementExplorer();}});

  renderForm();
  updateAll();
})();
