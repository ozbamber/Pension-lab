# Sources and planning references

These references are **context for the UI**, not guarantees used by the calculation engine.

## Israel inflation target

Bank of Israel: the current price-stability target is annual inflation of **1%–3%**.

- https://www.boi.org.il/en/bank-of-israel/about-the-bank-of-israel/objectives-and-functions/
- https://www.boi.org.il/publications/pressreleases/6-11-24/

The simulator therefore shows 1%–3% as a contextual range, while leaving inflation fully editable.

## Pension return-assurance mechanism

Israeli Ministry of Finance / Capital Market Authority materials describe the replacement of designated bonds with a return-assurance mechanism covering **30% of eligible pension assets**, with a **5.15% annual real return target** under the current mechanism.

- https://www.gov.il/he/pages/regulation_0005
- https://www.gov.il/he/pages/press_19052024

The simulator makes this an optional planning approximation. It is not assumed to remain unchanged over a multi-decade projection.

## Return assumptions

The 4%–6% real range shown in the interface is deliberately labeled a **planning range**, not a forecast. Users can enter any return assumptions and split them into multiple phases.
