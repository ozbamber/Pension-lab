# Pension Lab — Hebrew RTL MVP

A universal, client-side Hebrew pension simulator.

## Run

The app has no dependencies. You can open `index.html` directly in a modern browser.

For a local HTTP server:

```bash
cd pension-lab-he
python3 -m http.server 8080
```

Then open `http://localhost:8080`.

## Test the calculation engine

```bash
node tests.js
```

## What is implemented

- Full Hebrew + RTL UI
- Editable current age and retirement age
- Current balance, salary and pensionable salary
- Fixed or percentage contributions, including severance component
- Multi-phase salary growth (real or nominal)
- Multi-phase investment returns (real or nominal)
- Optional protected-return planning approximation
- Inflation and real/nominal views
- Career breaks with partial contributions and salary restart rules
- Asset/deposit fees
- Pension conversion coefficient + sensitivity
- Monthly calculation engine
- Balance-over-time chart
- Retirement-age explorer
- Scenario presets
- Local scenario saving and comparison
- Responsive desktop/mobile layout
- 10 unit tests for the projection engine

## Important modeling notes

- The defaults are example data, not a recommendation.
- The 30% / 5.15% protected-return values are presented only as a planning reference for the current Israeli mechanism; they are optional and not assumed to persist forever.
- The app does not model taxes or National Insurance benefits.
- The projection is deterministic; Monte Carlo is intentionally not included in this MVP.
